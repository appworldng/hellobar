<div id="wpbody" role="main">
	<style>a.clear{text-decoration: none;}</style>
    <div id="wpbody-content" aria-label="Main content" tabindex="0" style="padding-bottom: 15px !important;">
		<div id="screen-meta" class="metabox-prefs">
            <div id="contextual-help-wrap" class="hidden no-sidebar" tabindex="-1" aria-label="Contextual Help Tab">
				<div id="contextual-help-back"></div>
				<div id="contextual-help-columns">
					<div class="contextual-help-tabs">
						<ul></ul>
					</div>
                    <div class="contextual-help-tabs-wrap"></div>
				</div>
			</div>
		</div>
		<div class="wrap about-wrap full-width-layout">
		    <h1>HelloBar</h1>
            <p class="about-text">A simple WordPress plugin to help you display a hello bar on every page of your site.</p>
            </p>
			<p>Contributors: <a class="clear" href="https://github.com/chigozieorunta">Chigozie Orunta</a></p>
            <h2 class="nav-tab-wrapper wp-clearfix">
    			<a href="#" class="nav-tab nav-tab-active">Settings</a>
		    </h2>
        </div>
    </div>
</div>