<section class="<?= (get_option('hellobar_position') == 'top') ? 'hellobar-top' : 'hellobar-bottom'; ?>">
    <span><?= get_option('hellobar_text'); ?></span>
</section>