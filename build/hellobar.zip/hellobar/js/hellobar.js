(function($) {
	
	//...
	
})( jQuery );