# hellobar
A simple WordPress plugin to help you display a hello bar on every page of your site.
